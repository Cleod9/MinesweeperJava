//Greg McLeod
//3.19.2008
//MineSweeper

class MineSweeperRunner
{
    public static void main(String[] args)
    {
	    
	    //Initiate a a new 10x10 game of MineSweeper
    	MineSweeper myGame = new MineSweeper(10);	
    }
}

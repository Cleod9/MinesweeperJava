Copyrighted � 2013 by Greg McLeod
https://github.com/cleod9

Free to use and/or modify without notifying me. Just do not re-distribute it under anyone else's name please!

-----------------------------------

About MineSweeper:

A MineSweeper program written in high school. Although the artwork leaves a lot to be desired, this is essentially the same as the Windows version, so it's pretty self explanatory. Make sure to compiled all of the Java files before attempting to run MineSweeperRunner.java.

Minimum required classes for using this application:

Grid.class
wQuit.class (already within Grid.java)